Universal AI Workspace — extension bundle placeholder.

The MV3 extension is under active construction. Check back shortly, or watch the
project page for the real download.
