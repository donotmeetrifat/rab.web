import './assets/index.ts-YPaBCnkH.js';
