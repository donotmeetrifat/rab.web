import './assets/service-worker.ts-46VcdwQs.js';
