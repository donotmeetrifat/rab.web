import{a as e,d as t,h as n,i as r,p as i,r as a}from"./conversations-CvZZwtmK.js";import{a as o,b as s,i as c,n as l,r as u,y as d}from"./AIManager-BRYkP0R1.js";var f=500;function p(e){return t([e.provider,e.model,e.temperature.toFixed(2),e.system??``,e.prompt].join(``))}async function m(e){let t=await c(),n=e.temperature??t.temperature,r=p({system:e.system,prompt:e.prompt,model:t.chatModel,temperature:n,provider:t.provider});if(!e.skipCache){let e=await i.aiPromptCache.get(r);if(e)return{text:e.text,cached:!0,usage:e.usage,costUSD:e.costUSD,model:e.model}}let a=await u({system:e.system,prompt:e.prompt,temperature:n,maxTokens:e.maxTokens,json:e.json,signal:e.signal}),o={hash:r,provider:t.provider,model:a.model,text:a.text,usage:a.usage,costUSD:a.costUSD,createdAt:Date.now()};return await i.aiPromptCache.put(o),h(),{...a,cached:!1}}async function h(){let e=await i.aiPromptCache.count();if(e<=f)return;let t=e-f,n=await i.aiPromptCache.orderBy(`createdAt`).limit(t).toArray();await i.aiPromptCache.bulkDelete(n.map(e=>e.hash))}function g(e,t,n={}){let r=n.maxTokens??6e3,i=Math.max(200,Math.floor(r/Math.max(1,t.length))),a=[`# Conversation: ${e.title||`(untitled)`}`,`Provider: ${e.provider}${e.model?`  · Model: ${e.model}`:``}`,``];for(let e of t.sort((e,t)=>e.order-t.order)){let t=e.role.toUpperCase(),n=s(e.markdown||e.content||``,i);a.push(`## ${t}\n${n}\n`)}return s(a.join(`
`),r)}function _(e){if(!e)return null;let t=e.trim();t.startsWith("```")&&(t=t.replace(/^```[a-z]*\n?/i,``).replace(/```$/,``).trim());let n=t.indexOf(`{`),r=t.lastIndexOf(`}`);if(n===-1||r===-1)return null;try{return JSON.parse(t.slice(n,r+1))}catch{return null}}var v=`You analyse AI chat transcripts and return strict JSON only.
Never include commentary, code fences, or trailing prose.
Every field is optional — omit rather than fabricate.`,y=`{
  "title": string,
  "shortSummary": string,      // 1 sentence
  "longSummary": string,       // 2-4 paragraphs
  "takeaways": string[],
  "decisions": string[],
  "actionItems": string[],
  "questionsAsked": string[],
  "questionsAnswered": string[],
  "technologies": string[],
  "languages": string[],
  "libraries": string[],
  "frameworks": string[],
  "databases": string[],
  "cloud": string[],
  "apis": string[],
  "importantUrls": string[],
  "importantFiles": string[],
  "importantCode": [{ "language": string, "code": string }],
  "difficulty": "beginner" | "intermediate" | "advanced",
  "topics": string[],
  "category": string,
  "smartTags": string[],
  "importanceScore": number,   // 0..1
  "learningScore": number      // 0..1
}`;async function b(e,t={}){let o=await a(e);if(!o)return null;let s=await i.aiSummaries.where(`conversationId`).equals(e).first();if(s&&!t.force&&s.hash===o.hash)return s;let l=await r(e),u=await c();t.onProgress?.(.1);let d=`Analyse the following AI chat transcript and return the JSON described in the schema. Schema:\n${y}\n\nTranscript:\n${g(o,l,{maxTokens:6e3})}`;t.onProgress?.(.3);let f=await m({system:v,prompt:d,temperature:.2,maxTokens:1600,json:!0,signal:t.signal,skipCache:t.force});t.onProgress?.(.85);let p=_(f.text)??{},h={id:s?.id??n(`aisum`),conversationId:e,provider:u.provider,model:f.model,hash:o.hash,...p,updatedAt:Date.now()};return await i.aiSummaries.put(h),t.onProgress?.(1),h}async function x(e){return await i.aiSummaries.where(`conversationId`).equals(e).first()??null}function S(e,t){if(e.length!==t.length||e.length===0)return 0;let n=0,r=0,i=0;for(let a=0;a<e.length;a++){let o=e[a],s=t[a];n+=o*s,r+=o*o,i+=s*s}let a=Math.sqrt(r)*Math.sqrt(i);return a===0?0:n/a}function C(e,t,n){return[`Title: ${e.title}`,`Provider: ${e.provider}`,t&&`Summary: ${t}`,``,n.slice(0,4e3)].filter(Boolean).join(`
`)}async function w(e,s=!1){if(!await o())return null;let u=await a(e);if(!u)return null;let d=await x(e),f=(await r(e)).sort((e,t)=>e.order-t.order).map(e=>`${e.role}: ${(e.content||e.markdown||``).slice(0,500)}`).join(`
`),p=C(u,[d?.shortSummary,d?.longSummary,(d?.topics??[]).join(`, `)].filter(Boolean).join(` | `),f),m=t(p),h=await i.aiEmbeddings.where({scope:`conversation`,conversationId:e}).first();if(h&&!s&&h.hash===m)return h;let g=await c(),{vectors:_,model:v}=await l({input:p}),y=_[0];if(!y)return null;let b={id:h?.id??n(`emb`),scope:`conversation`,conversationId:e,chunkIndex:0,text:p,vector:y,model:v,provider:g.provider,hash:m,createdAt:Date.now()};return await i.aiEmbeddings.put(b),b}async function T(t){let n=await e(),r=0,a=0;for(let e=0;e<n.length;e++){let o=n[e],s=await i.aiEmbeddings.where({scope:`conversation`,conversationId:o.id}).first(),c=await w(o.id).catch(()=>null);c&&(!s||c.id!==s.id||c.hash!==s.hash)?r+=1:a+=1,t?.(e+1,n.length)}return{embedded:r,skipped:a}}async function E(t,n=10){if(!t.trim()||!await o())return[];let{vectors:r}=await l({input:t}),a=r[0];if(!a)return[];let s=await i.aiEmbeddings.where(`scope`).equals(`conversation`).toArray(),c=[],u=new Map;for(let t of await e())u.set(t.id,t.title);for(let e of s){let t=S(a,e.vector);c.push({conversationId:e.conversationId,title:u.get(e.conversationId)??`(untitled)`,similarity:t,text:e.text.slice(0,200)})}return c.sort((e,t)=>t.similarity-e.similarity).slice(0,n)}async function D(){let e=await i.aiEmbeddings.toArray(),t=e.reduce((e,t)=>e+d(t.text),0);return{vectors:e.length,tokens:t,model:e[0]?.model??null}}async function O(){await i.aiEmbeddings.clear()}export{E as a,m as c,D as i,g as l,T as n,x as o,w as r,b as s,O as t};