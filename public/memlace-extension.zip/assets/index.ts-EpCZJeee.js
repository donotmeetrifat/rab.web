import{a as e,n as t,t as n}from"./settings-Cytufu3e.js";import{a as r,r as i}from"./conversations-CDs4acKt.js";function a(e,t){let n=null;return(...r)=>{n!==null&&clearTimeout(n),n=window.setTimeout(()=>e(...r),t)}}function o(e){return e.textContent?.replace(/\u00a0/g,` `).trim()??``}function s(e){let t=[];return c(e,t,{listDepth:0,ordered:[]}),d(t.join(``))}function c(e,t,n){if(e.nodeType===Node.TEXT_NODE){t.push(u(e.textContent??``));return}if(e.nodeType!==Node.ELEMENT_NODE)return;let r=e,i=r.tagName.toLowerCase();switch(i){case`br`:t.push(`  
`);return;case`hr`:t.push(`

---

`);return;case`strong`:case`b`:t.push(`**`),l(r,t,n),t.push(`**`);return;case`em`:case`i`:t.push(`*`),l(r,t,n),t.push(`*`);return;case`del`:case`s`:t.push(`~~`),l(r,t,n),t.push(`~~`);return;case`a`:{let e=r.href;t.push(`[`),l(r,t,n),t.push(`](${e})`);return}case`code`:r.parentElement?.tagName.toLowerCase()===`pre`?l(r,t,n):t.push("`"+(r.textContent??``).replace(/`/g,"\\`")+"`");return;case`pre`:{let e=r.querySelector(`code`),n=e?.className.match(/language-([\w+-]+)/)?.[1]??``,i=(e??r).textContent??``;t.push(`\n\n\`\`\`${n}\n${i.replace(/\n+$/,``)}\n\`\`\`\n\n`);return}case`blockquote`:{let e=[];l(r,e,n);let i=e.join(``).split(`
`).map(e=>e?`> ${e}`:`>`).join(`
`);t.push(`\n\n${i}\n\n`);return}case`h1`:case`h2`:case`h3`:case`h4`:case`h5`:case`h6`:{let e=Number(i[1]);t.push(`\n\n${`#`.repeat(e)} `),l(r,t,n),t.push(`

`);return}case`p`:t.push(`

`),l(r,t,n),t.push(`

`);return;case`ul`:case`ol`:{let e=i===`ol`;n.ordered.push({index:1,ordered:e}),n.listDepth++,t.push(`
`);for(let i of Array.from(r.children)){if(i.tagName.toLowerCase()!==`li`)continue;let r=`  `.repeat(n.listDepth-1),a=e?`${n.ordered[n.ordered.length-1].index++}.`:`-`;t.push(`${r}${a} `),l(i,t,n),t.push(`
`)}n.listDepth--,n.ordered.pop(),t.push(`
`);return}case`table`:{let e=Array.from(r.querySelectorAll(`tr`));if(e.length===0)return;t.push(`

`),e.forEach((e,n)=>{let r=Array.from(e.children),i=r.map(e=>(e.textContent??``).replace(/\|/g,`\\|`).trim()).join(` | `);t.push(`| ${i} |\n`),n===0&&t.push(`| ${r.map(()=>`---`).join(` | `)} |\n`)}),t.push(`
`);return}case`img`:{let e=r;t.push(`![${e.alt||``}](${e.src})`);return}case`svg`:case`style`:case`script`:return;default:l(r,t,n)}}function l(e,t,n){for(let r of Array.from(e.childNodes))c(r,t,n)}function u(e){return e.replace(/\r/g,``)}function d(e){return e.replace(/\n{3,}/g,`

`).trim()}var f=/^(chatgpt\.com|chat\.openai\.com)$/i,p=`memlace-save-btn`,m=[`main`,`#__next`,`body`],h=`[data-message-author-role]`,g=class{id=`chatgpt`;name=`ChatGPT`;observer=null;buttonReinjectObserver=null;stateListener=null;buttonEl=null;handlers=null;matches(e){try{return f.test(new URL(e).hostname)}catch{return!1}}detect(){return document.querySelector(h)!==null}getConversationId(){let e=location.pathname.match(/\/c\/([\w-]+)/);if(e)return e[1];let t=document.querySelector(h);return t?`draft:${y(o(t).slice(0,120))}`:null}getTitle(){let e=document.querySelector(`nav a[aria-current="page"], nav a[data-active="true"]`),t=e?o(e):``;if(t)return t;let n=document.title.replace(/\s*[|·-]\s*ChatGPT\s*$/i,``).trim();if(n&&n.toLowerCase()!==`chatgpt`)return n;let r=document.querySelector(`[data-message-author-role="user"]`);return r&&o(r).slice(0,80)||`ChatGPT conversation`}getMessages(){let e=Array.from(document.querySelectorAll(h)),t=[];return e.forEach((e,n)=>{let r=_(e.getAttribute(`data-message-author-role`));if(!r)return;let i=e.querySelector(`.markdown`)??e.querySelector(`.whitespace-pre-wrap`)??e,a=s(i),c=o(i);if(!a&&!c)return;let l=Array.from(e.querySelectorAll(`img`)).map(e=>e.src).filter(e=>e&&!e.startsWith(`data:`)),u=Array.from(e.querySelectorAll(`a[href^="http"]`)).slice(0,8).map(e=>({kind:`link`,url:e.href,name:o(e)})),d=e.getAttribute(`data-message-id`)??`${r}:${n}:${y(a||c)}`,f=e.querySelector(`[data-testid="reasoning"], [data-message-metadata*="thinking"]`);t.push({id:d,role:r,content:c,markdown:a,images:l,attachments:u,order:n,metadata:{...f?{thinking:o(f)}:{}}})}),t}getConversation(){let e=this.getConversationId();if(!e)return null;let t=this.getMessages();return t.length===0?null:{provider:this.id,conversationId:e,title:this.getTitle(),url:location.href,model:this.getModel(),messages:t,capturedAt:Date.now()}}observeChanges(e){let t=v(m)??document.body,n=a(e,900);return this.observer?.disconnect(),this.observer=new MutationObserver(e=>{for(let t of e){let e=t.target;if(!(e&&e.id===p)){n();return}}}),this.observer.observe(t,{subtree:!0,childList:!0,characterData:!0}),()=>this.observer?.disconnect()}injectButton(e){return this.handlers=e,this.mountButton(),this.buttonReinjectObserver?.disconnect(),this.buttonReinjectObserver=new MutationObserver(()=>{document.getElementById(p)||this.mountButton()}),this.buttonReinjectObserver.observe(document.body,{subtree:!0,childList:!0}),this.stateListener=e=>{let t=e.detail;this.applyButtonState(t)},window.addEventListener(`memlace:save-state`,this.stateListener),()=>{this.buttonReinjectObserver?.disconnect(),this.buttonReinjectObserver=null,this.stateListener&&=(window.removeEventListener(`memlace:save-state`,this.stateListener),null),this.buttonEl?.remove(),this.buttonEl=null}}cleanup(){this.observer?.disconnect(),this.observer=null,this.buttonReinjectObserver?.disconnect(),this.buttonReinjectObserver=null,this.stateListener&&=(window.removeEventListener(`memlace:save-state`,this.stateListener),null),this.buttonEl?.remove(),this.buttonEl=null,this.handlers=null}getModel(){let e=document.querySelector(`[data-testid="model-switcher-dropdown-button"], [aria-label*="Model"]`);return(e?o(e):``)||null}mountButton(){if(document.getElementById(p))return;let e=b(),t=document.createElement(`button`);if(t.id=p,t.type=`button`,t.setAttribute(`aria-label`,`Save conversation to Memlace`),t.setAttribute(`data-memlace`,`save-btn`),t.addEventListener(`click`,e=>{e.preventDefault(),e.stopPropagation(),this.handlers?.onSave()}),e){t.className=`memlace-save-btn memlace-save-btn--native`,t.innerHTML=T;let n=e.querySelector(`[data-testid="send-button"], button[aria-label*="Send" i]`);n&&n.parentElement===e?e.insertBefore(t,n):e.appendChild(t)}else t.className=`memlace-save-btn memlace-save-btn--floating`,t.innerHTML=E,Object.assign(t.style,D),document.body.appendChild(t);k(),this.buttonEl=t,this.applyButtonState(this.handlers?.getState()??`idle`)}applyButtonState(e){if(!this.buttonEl)return;let t=this.buttonEl.querySelector(`.memlace-btn-label`),n=this.buttonEl.querySelector(`.memlace-btn-icon`),r=w[e];t&&(t.textContent=r.text),n&&(n.innerHTML=r.iconSvg),this.buttonEl.dataset.state=e,this.buttonEl.setAttribute(`aria-busy`,e===`saving`?`true`:`false`),this.buttonEl.title=r.tooltip}};function _(e){switch(e){case`user`:case`assistant`:case`system`:case`tool`:return e;default:return null}}function v(e){for(let t of e){let e=document.querySelector(t);if(e)return e}return null}function y(e){let t=2166136261;for(let n=0;n<e.length;n++)t^=e.charCodeAt(n),t=t+((t<<1)+(t<<4)+(t<<7)+(t<<8)+(t<<24))>>>0;return t.toString(16)}function b(){let e=document.querySelector(`form [data-testid="send-button"], form button[aria-label*="Send" i]`);if(!e)return null;let t=e.parentElement;for(let e=0;t&&e<5;e++,t=t.parentElement){let e=t.querySelectorAll(`:scope > button`).length;if(e>=2||e+t.querySelectorAll(`:scope > div > button, :scope > span > button`).length>=2)return t}return e.parentElement}var x=`<svg viewBox="0 0 20 20" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M5 3.5h10v13l-5-3-5 3v-13z"/></svg>`,S=`<svg viewBox="0 0 20 20" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" class="memlace-spin"><path d="M10 2.5a7.5 7.5 0 1 1-7.5 7.5" opacity=".9"/></svg>`,C=`<svg viewBox="0 0 20 20" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 10.5l4 4 8-9"/></svg>`,w={idle:{text:`Save to Memlace`,iconSvg:x,tooltip:`Save this conversation to Memlace`},saving:{text:`Saving…`,iconSvg:S,tooltip:`Saving conversation…`},saved:{text:`Saved ✓`,iconSvg:C,tooltip:`Saved to Memlace`},updated:{text:`Updated ✓`,iconSvg:C,tooltip:`Updated in Memlace`},error:{text:`Retry`,iconSvg:`<svg viewBox="0 0 20 20" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M15.5 10a5.5 5.5 0 1 1-1.6-3.9"/><path d="M15.5 4v3.5H12"/></svg>`,tooltip:`Save failed — click to retry`}},T=`
  <span class="memlace-btn-icon" aria-hidden="true">${x}</span>
  <span class="memlace-btn-label">Save to Memlace</span>
`,E=`
  <span class="memlace-btn-icon" aria-hidden="true">${x}</span>
  <span class="memlace-btn-label">Save to Memlace</span>
`,D={position:`fixed`,right:`20px`,bottom:`104px`,zIndex:`2147483000`},O=`memlace-save-btn-styles`;function k(){if(document.getElementById(O))return;let e=document.createElement(`style`);e.id=O,e.textContent=`
    .memlace-save-btn {
      all: unset;
      box-sizing: border-box;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      cursor: pointer;
      user-select: none;
      font: 500 13px/1 ui-sans-serif, -apple-system, BlinkMacSystemFont, "Segoe UI", Inter, sans-serif;
      transition: background 140ms ease, color 140ms ease, border-color 140ms ease, transform 120ms ease;
    }
    .memlace-save-btn:focus-visible {
      outline: 2px solid #2563EB;
      outline-offset: 2px;
    }
    .memlace-save-btn .memlace-btn-icon {
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }
    .memlace-save-btn .memlace-spin {
      animation: memlace-spin 900ms linear infinite;
      transform-origin: 50% 50%;
    }
    @keyframes memlace-spin { to { transform: rotate(360deg); } }

    /* -------- Native (inside ChatGPT composer toolbar) -------- */
    .memlace-save-btn--native {
      height: 32px;
      padding: 0 10px;
      margin: 0 4px;
      border-radius: 9999px;
      color: inherit;
      background: transparent;
      border: 1px solid rgba(0,0,0,0.12);
    }
    .memlace-save-btn--native:hover {
      background: rgba(0,0,0,0.05);
    }
    @media (prefers-color-scheme: dark) {
      .memlace-save-btn--native {
        border-color: rgba(255,255,255,0.16);
        color: rgba(255,255,255,0.92);
      }
      .memlace-save-btn--native:hover {
        background: rgba(255,255,255,0.08);
      }
    }
    .memlace-save-btn--native[data-state="saved"],
    .memlace-save-btn--native[data-state="updated"] {
      color: #047857;
      border-color: rgba(4,120,87,0.35);
      background: rgba(16,185,129,0.10);
    }
    .memlace-save-btn--native[data-state="saving"] {
      color: #2563EB;
      border-color: rgba(37,99,235,0.35);
      background: rgba(37,99,235,0.08);
    }
    .memlace-save-btn--native[data-state="error"] {
      color: #B91C1C;
      border-color: rgba(185,28,28,0.35);
      background: rgba(220,38,38,0.08);
    }

    /* -------- Floating fallback -------- */
    .memlace-save-btn--floating {
      height: 40px;
      padding: 0 14px;
      border-radius: 10px;
      color: #FFFFFF;
      background: #2563EB;
      border: 1px solid rgba(255,255,255,0.14);
      box-shadow: 0 10px 24px rgba(37,99,235,0.28), 0 2px 4px rgba(15,23,42,0.12), inset 0 1px 0 rgba(255,255,255,0.24);
    }
    .memlace-save-btn--floating:hover { transform: translateY(-1px); }
    .memlace-save-btn--floating[data-state="saving"]  { background: #1D4ED8; }
    .memlace-save-btn--floating[data-state="saved"],
    .memlace-save-btn--floating[data-state="updated"] { background: #059669; }
    .memlace-save-btn--floating[data-state="error"]   { background: #DC2626; }
  `,(document.head||document.documentElement).appendChild(e)}var A=class{id;name;hostPattern;constructor(e,t,n){this.id=e,this.name=t,this.hostPattern=n}matches(e){try{return this.hostPattern.test(new URL(e).hostname)}catch{return!1}}detect(){return!1}getConversationId(){return null}getTitle(){return this.name}getMessages(){return[]}getConversation(){return null}observeChanges(){return()=>void 0}injectButton(){return()=>void 0}cleanup(){}},j=class extends A{constructor(){super(`claude`,`Claude`,/(^|\.)claude\.ai$/i)}},M=class extends A{constructor(){super(`gemini`,`Gemini`,/(^|\.)gemini\.google\.com$/i)}},N=class extends A{constructor(){super(`deepseek`,`DeepSeek`,/(^|\.)chat\.deepseek\.com$/i)}},P=class extends A{constructor(){super(`perplexity`,`Perplexity`,/(^|\.)perplexity\.ai$/i)}},F=class extends A{constructor(){super(`copilot`,`Copilot`,/(^|\.)copilot\.microsoft\.com$/i)}},I=class extends A{constructor(){super(`aistudio`,`AI Studio`,/(^|\.)aistudio\.google\.com$/i)}},L=class{events;adapters;active=null;disposeObserver=null;disposeButton=null;lastHash=null;lastConversationId=null;saveState=`idle`;pendingSaveTimer=null;urlPollTimer=null;currentUrl=``;disposed=!1;constructor(e,t){this.events=t,this.adapters=e}start(){this.currentUrl=location.href,this.reconcile(`initial`),R(()=>this.onUrlMaybeChanged()),window.addEventListener(`popstate`,this.onUrlMaybeChanged),this.urlPollTimer=window.setInterval(this.onUrlMaybeChanged,1500)}cleanup(){this.disposed=!0,window.removeEventListener(`popstate`,this.onUrlMaybeChanged),this.urlPollTimer!==null&&clearInterval(this.urlPollTimer),this.pendingSaveTimer!==null&&clearTimeout(this.pendingSaveTimer),this.tearDownActive()}async saveNow(){if(!this.active)return{ok:!1,error:`No supported AI page detected`};let e=this.active.getConversation();if(!e)return{ok:!1,error:`No conversation on this page yet`};try{this.setSaveState(`saving`);let t=r(e),n=this.lastHash!==null&&this.lastHash!==t;return await this.events.onConversationChanged({conversation:e,hash:t,reason:`manual`}),this.lastHash=t,this.setSaveState(n?`updated`:`saved`),window.setTimeout(()=>this.setSaveState(`idle`),2200),{ok:!0}}catch(e){return this.setSaveState(`error`),window.setTimeout(()=>this.setSaveState(`idle`),2600),{ok:!1,error:e instanceof Error?e.message:`Save failed`}}}onUrlMaybeChanged=()=>{this.disposed||location.href!==this.currentUrl&&(this.currentUrl=location.href,this.reconcile(`initial`))};reconcile(e){let t=location.href,n=this.adapters.find(e=>e.matches(t))??null;n!==this.active&&(this.tearDownActive(),this.active=n,this.lastHash=null,this.lastConversationId=null),this.active&&z(()=>this.active?.detect()===!0,()=>this.wireActive(e))}wireActive(e){!this.active||this.disposed||(this.disposeObserver||=this.active.observeChanges(()=>this.scheduleSnapshot()),this.disposeButton||=this.active.injectButton({onSave:async()=>{await this.saveNow()},getState:()=>this.saveState}),this.scheduleSnapshot(e))}scheduleSnapshot(e=`auto`){this.pendingSaveTimer!==null&&clearTimeout(this.pendingSaveTimer),this.pendingSaveTimer=window.setTimeout(()=>{this.pendingSaveTimer=null,this.snapshot(e)},700)}async snapshot(e){if(!this.active||this.disposed)return;let t=this.active.getConversation();if(!t||t.messages.length===0)return;this.lastConversationId&&this.lastConversationId!==t.conversationId&&(this.lastHash=null),this.lastConversationId=t.conversationId;let n=r(t);if(n!==this.lastHash){if(!this.events.isAutoSaveEnabled()&&e!==`initial`){this.lastHash=n;return}if(!this.events.isAutoSaveEnabled()){this.lastHash=n;return}try{this.setSaveState(`saving`),await this.events.onConversationChanged({conversation:t,hash:n,reason:`auto`});let e=this.lastHash!==null;this.lastHash=n,this.setSaveState(e?`updated`:`saved`),window.setTimeout(()=>this.setSaveState(`idle`),1800)}catch{this.setSaveState(`error`),window.setTimeout(()=>this.setSaveState(`idle`),2400)}}}setSaveState(e){this.saveState=e,window.dispatchEvent(new CustomEvent(`memlace:save-state`,{detail:e}))}tearDownActive(){this.disposeObserver?.(),this.disposeObserver=null,this.disposeButton?.(),this.disposeButton=null,this.active?.cleanup()}};function R(e){let t=window;if(t.__memlaceHistoryHooked){window.addEventListener(`memlace:locationchange`,e);return}t.__memlaceHistoryHooked=!0;let n=()=>window.dispatchEvent(new Event(`memlace:locationchange`)),r=history.pushState,i=history.replaceState;history.pushState=function(...e){let t=r.apply(this,e);return n(),t},history.replaceState=function(...e){let t=i.apply(this,e);return n(),t},window.addEventListener(`memlace:locationchange`,e)}function z(e,t){let n=Date.now(),r=()=>{if(e()){t();return}Date.now()-n>3e4||window.setTimeout(r,400)};r()}function B(){return[new g,new j,new M,new N,new P,new F,new I]}var V=n;t().then(e=>{V=e}),e(e=>{V=e});var H=new L(B(),{isAutoSaveEnabled:()=>V.autoSaveConversations&&!V.saveConversationsManualOnly,onConversationChanged:async({conversation:e,hash:t,reason:n})=>{if(n!==`manual`&&V.saveConversationsManualOnly)return;let{created:r}=await i(e,{hash:t,source:n,saveImages:V.saveImages,saveAttachments:V.saveAttachments});try{await chrome.runtime.sendMessage({type:`CONVERSATION_SAVED`,payload:{provider:e.provider,title:e.title,created:r,source:n}})}catch{}}});H.start();function U(){let e=window.getSelection();return e?e.toString().trim():``}window.addEventListener(`keydown`,e=>{if(e.altKey&&e.shiftKey&&e.code===`KeyS`){let t=U();if(!t)return;e.preventDefault(),chrome.runtime.sendMessage({type:`CAPTURE_SELECTION`,payload:{text:t,url:location.href,title:document.title}}).catch(()=>void 0)}}),window.addEventListener(`beforeunload`,()=>H.cleanup());