import{i as e,n as t}from"./contextReadiness-CnFdh4Qz.js";import{a as n,b as r,i,n as a,r as o,y as s}from"./AIManager-_8wSW517.js";import{a as c,d as l,i as u,r as d}from"./conversations-C4W-khrb.js";var f=500;function p(e){return l([e.provider,e.model,e.temperature.toFixed(2),e.system??``,e.prompt].join(``))}async function m(e){let n=await i(),r=e.temperature??n.temperature,a=p({system:e.system,prompt:e.prompt,model:n.chatModel,temperature:r,provider:n.provider});if(!e.skipCache){let e=await t.aiPromptCache.get(a);if(e)return{text:e.text,cached:!0,usage:e.usage,costUSD:e.costUSD,model:e.model}}let s=await o({system:e.system,prompt:e.prompt,temperature:r,maxTokens:e.maxTokens,json:e.json,signal:e.signal}),c={hash:a,provider:n.provider,model:s.model,text:s.text,usage:s.usage,costUSD:s.costUSD,createdAt:Date.now()};return await t.aiPromptCache.put(c),h(),{...s,cached:!1}}async function h(){let e=await t.aiPromptCache.count();if(e<=f)return;let n=e-f,r=await t.aiPromptCache.orderBy(`createdAt`).limit(n).toArray();await t.aiPromptCache.bulkDelete(r.map(e=>e.hash))}function g(e,t,n={}){let i=n.maxTokens??6e3,a=Math.max(200,Math.floor(i/Math.max(1,t.length))),o=[`# Conversation: ${e.title||`(untitled)`}`,`Provider: ${e.provider}${e.model?`  · Model: ${e.model}`:``}`,``];for(let e of t.sort((e,t)=>e.order-t.order)){let t=e.role.toUpperCase(),n=r(e.markdown||e.content||``,a);o.push(`## ${t}\n${n}\n`)}return r(o.join(`
`),i)}function _(e){if(!e)return null;let t=e.trim();t.startsWith("```")&&(t=t.replace(/^```[a-z]*\n?/i,``).replace(/```$/,``).trim());let n=t.indexOf(`{`),r=t.lastIndexOf(`}`);if(n===-1||r===-1)return null;try{return JSON.parse(t.slice(n,r+1))}catch{return null}}var v=`You analyse AI chat transcripts and return strict JSON only.
Never include commentary, code fences, or trailing prose.
Every field is optional — omit rather than fabricate.`,y=`{
  "title": string,
  "shortSummary": string,      // 1 sentence
  "longSummary": string,       // 2-4 paragraphs
  "takeaways": string[],
  "decisions": string[],
  "actionItems": string[],
  "questionsAsked": string[],
  "questionsAnswered": string[],
  "technologies": string[],
  "languages": string[],
  "libraries": string[],
  "frameworks": string[],
  "databases": string[],
  "cloud": string[],
  "apis": string[],
  "importantUrls": string[],
  "importantFiles": string[],
  "importantCode": [{ "language": string, "code": string }],
  "difficulty": "beginner" | "intermediate" | "advanced",
  "topics": string[],
  "category": string,
  "smartTags": string[],
  "importanceScore": number,   // 0..1
  "learningScore": number      // 0..1
}`;async function b(n,r={}){let a=await d(n);if(!a)return null;let o=await t.aiSummaries.where(`conversationId`).equals(n).first();if(o&&!r.force&&o.hash===a.hash)return o;let s=await u(n),c=await i();r.onProgress?.(.1);let l=`Analyse the following AI chat transcript and return the JSON described in the schema. Schema:\n${y}\n\nTranscript:\n${g(a,s,{maxTokens:6e3})}`;r.onProgress?.(.3);let f=await m({system:v,prompt:l,temperature:.2,maxTokens:1600,json:!0,signal:r.signal,skipCache:r.force});r.onProgress?.(.85);let p=_(f.text)??{},h={id:o?.id??e(`aisum`),conversationId:n,provider:c.provider,model:f.model,hash:a.hash,...p,updatedAt:Date.now()};return await t.aiSummaries.put(h),r.onProgress?.(1),h}async function x(e){return await t.aiSummaries.where(`conversationId`).equals(e).first()??null}function S(e,t){if(e.length!==t.length||e.length===0)return 0;let n=0,r=0,i=0;for(let a=0;a<e.length;a++){let o=e[a],s=t[a];n+=o*s,r+=o*o,i+=s*s}let a=Math.sqrt(r)*Math.sqrt(i);return a===0?0:n/a}function C(e,t,n){return[`Title: ${e.title}`,`Provider: ${e.provider}`,t&&`Summary: ${t}`,``,n.slice(0,4e3)].filter(Boolean).join(`
`)}async function w(r,o=!1){if(!await n())return null;let s=await d(r);if(!s)return null;let c=await x(r),f=(await u(r)).sort((e,t)=>e.order-t.order).map(e=>`${e.role}: ${(e.content||e.markdown||``).slice(0,500)}`).join(`
`),p=C(s,[c?.shortSummary,c?.longSummary,(c?.topics??[]).join(`, `)].filter(Boolean).join(` | `),f),m=l(p),h=await t.aiEmbeddings.where({scope:`conversation`,conversationId:r}).first();if(h&&!o&&h.hash===m)return h;let g=await i(),{vectors:_,model:v}=await a({input:p}),y=_[0];if(!y)return null;let b={id:h?.id??e(`emb`),scope:`conversation`,conversationId:r,chunkIndex:0,text:p,vector:y,model:v,provider:g.provider,hash:m,createdAt:Date.now()};return await t.aiEmbeddings.put(b),b}async function T(e){let n=await c(),r=0,i=0;for(let a=0;a<n.length;a++){let o=n[a],s=await t.aiEmbeddings.where({scope:`conversation`,conversationId:o.id}).first(),c=await w(o.id).catch(()=>null);c&&(!s||c.id!==s.id||c.hash!==s.hash)?r+=1:i+=1,e?.(a+1,n.length)}return{embedded:r,skipped:i}}async function E(e,r=10){if(!e.trim()||!await n())return[];let{vectors:i}=await a({input:e}),o=i[0];if(!o)return[];let s=await t.aiEmbeddings.where(`scope`).equals(`conversation`).toArray(),l=[],u=new Map;for(let e of await c())u.set(e.id,e.title);for(let e of s){let t=S(o,e.vector);l.push({conversationId:e.conversationId,title:u.get(e.conversationId)??`(untitled)`,similarity:t,text:e.text.slice(0,200)})}return l.sort((e,t)=>t.similarity-e.similarity).slice(0,r)}async function D(){let e=await t.aiEmbeddings.toArray(),n=e.reduce((e,t)=>e+s(t.text),0);return{vectors:e.length,tokens:n,model:e[0]?.model??null}}async function O(){await t.aiEmbeddings.clear()}export{E as a,m as c,D as i,g as l,T as n,x as o,w as r,b as s,O as t};